﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HeroController : MonoBehaviour
{
    //Maximum Movement Values
    public float walkSpeed;
    public float sneakSpeed;
    public float runSpeed;

    //Movement Inertia Modifier
    public float inertia;
    private Vector3 movement;
    private Rigidbody2D rb;

    //Finite States
    private enum moveState
    {
        sneak, 
        walk,
        run,
        idle,
        hide
    }
    moveState motion;

    //Collision with Object Interaction
    private enum nextTo
    {
        hide,
        search,
        open
    }
    nextTo proximity;

    public bool isColliding;

    //Invisibiliy attempt
    SpriteRenderer visible;

    //Hero Instantiation
    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        proximity = nextTo.open;
        motion = moveState.idle;
        visible = GetComponent<SpriteRenderer>();
        inertia = 10.0f;
        isColliding = false;
        //GUI.Label(new Rect(10, 10, 100, 20), proximity + " " + motion);
    }

    //Update 
    private void FixedUpdate()
    {
        updateMovement();
        
        //World Clamp
        Vector3 position = Camera.main.WorldToViewportPoint(transform.position);
        position.x = Mathf.Clamp01(position.x);
        position.y = Mathf.Clamp01(position.y);
        transform.position = Camera.main.ViewportToWorldPoint(position);
    }

    private void updateMovement()
    {
        var x = Input.GetAxisRaw("Horizontal");
        var y = Input.GetAxisRaw("Vertical");
        movement = new Vector3(x, y, 0.0f);

        // TEST MOVEMENT
        Quaternion rotate = Quaternion.LookRotation(Vector3.forward, movement);
        transform.rotation = rotate;
        transform.eulerAngles = new Vector3(0, 0, -transform.eulerAngles.z);
        rb.angularVelocity = 0;

        rb.AddForce(new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical")) * walkSpeed);
        //

        //        transform.forward = Vector3.Normalize(new Vector3(Input.GetAxis("Horizontal"), 0f, Input.GetAxis("Vertical")));
        Debug.Log(motion);
        Debug.Log(proximity);

        if (Input.GetButton("Fire1") && !Input.GetButton("Fire2")) //Sneak
        {
            motion = moveState.sneak;
            rb.AddForce(new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical")) * sneakSpeed);
         //   transform.position += Input.GetAxis("Vertical") * transform.up * (sneakSpeed * Time.smoothDeltaTime);
         // transform.Rotate(transform.forward, -((Input.GetAxis("Horizontal") * (sneakSpeed * Time.smoothDeltaTime * 10))));
        }
        else if (Input.GetButton("Fire2") && !Input.GetButton("Fire1")) //Run
        {
            motion = moveState.run;

            rb.AddForce(new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical")) * runSpeed);
            //transform.position += Input.GetAxis("Vertical") * transform.up * (runSpeed * Time.smoothDeltaTime);
            //transform.position += movement * runSpeed * Time.smoothDeltaTime;
            //transform.Rotate(transform.forward, -((Input.GetAxis("Horizontal") * (runSpeed * Time.smoothDeltaTime * 10))));
        }
        else if (movement.magnitude != 0)
        {
            motion = moveState.walk;

            rb.AddForce(new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical")) * walkSpeed);
            //transform.position += Input.GetAxis("Vertical") * transform.up * (walkSpeed * Time.smoothDeltaTime);
            //transform.position += movement * baseSpeed * Time.smoothDeltaTime;
            //transform.Rotate(transform.forward, -((Input.GetAxis("Horizontal") * (walkSpeed * Time.smoothDeltaTime * 10))));
        }
        else if (proximity == nextTo.hide && Input.GetButton("Jump"))
        {
            motion = moveState.hide;
        }
        else
        {
            motion = moveState.idle;
        }

        //INVISIBILITY
        if (motion == moveState.hide)
        {
            visible.enabled = false;
        }
        else
        {
            visible.enabled = true;
        }
        
        if (proximity == nextTo.search && Input.GetButton("Jump"))
        {
            
        }
    }
    private void OnCollisionExit2D(Collision2D collision)
    {
        proximity = nextTo.open;
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "HideObject")
        {
            proximity = nextTo.hide;
        }

        if (collision.gameObject.tag == "SearchObject")
        {
            proximity = nextTo.search;
        }
        /*
        if (collision.gameObject.tag == "UseObject")
        {

        }
        */
    }

    void searchItem()
    {

    }
} 
